const CONFIG = require('../config/config');

function hasRole(member, roleType) {
  if (!member) return false;
  const roleId = CONFIG.roles[roleType];
  if (!roleId) return false;
  return member.roles.cache.has(roleId);
}

function checkRoleAccess(member, requiredRole) {
  switch (requiredRole) {
    case 'vip':
      return hasRole(member, 'vip') || hasRole(member, 'admin');
    case 'premium':
      return hasRole(member, 'premium') || hasRole(member, 'vip') || hasRole(member, 'admin');
    case 'admin':
      return hasRole(member, 'admin');
    case 'member':
    default:
      return true;
  }
}

module.exports = {
  hasRole,
  checkRoleAccess,
};