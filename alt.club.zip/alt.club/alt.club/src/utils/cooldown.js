const CONFIG = require('../config/config');

const userCooldowns = new Map();

function getUserCooldown(member) {
  if (!member) return CONFIG.cooldowns.default;
  if (member.roles.cache.has(CONFIG.roles.admin)) return CONFIG.cooldowns.admin;
  if (member.roles.cache.has(CONFIG.roles.premium)) return CONFIG.cooldowns.premium;
  if (member.roles.cache.has(CONFIG.roles.vip)) return CONFIG.cooldowns.vip;
  return CONFIG.cooldowns.default;
}

function checkCooldown(userId, commandName = 'default') {
  const key = `${userId}:${commandName}`;
  if (!userCooldowns.has(key)) return { onCooldown: false };

  const cooldownEnd = userCooldowns.get(key);
  const now = Date.now();

  if (now < cooldownEnd) {
    return { onCooldown: true, timeLeft: cooldownEnd - now };
  }

  userCooldowns.delete(key);
  return { onCooldown: false };
}

function setCooldown(userId, cooldownTime, commandName = 'default') {
  if (cooldownTime > 0) {
    const key = `${userId}:${commandName}`;
    userCooldowns.set(key, Date.now() + cooldownTime);
  }
}

function removeCooldown(userId, commandName = 'default') {
  const key = `${userId}:${commandName}`;
  userCooldowns.delete(key);
}

module.exports = {
  getUserCooldown,
  checkCooldown,
  setCooldown,
  removeCooldown,
};
