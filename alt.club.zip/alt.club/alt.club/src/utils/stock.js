const fs = require('fs').promises;
const CONFIG = require('../config/config');

async function readStock() {
  try {
    const data = await fs.readFile(CONFIG.stockFile, 'utf-8');
    return data.split('\n').filter(line => line.trim());
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
}

async function writeStock(lines) {
  await fs.writeFile(CONFIG.stockFile, lines.join('\n'), 'utf-8');
}

module.exports = {
  readStock,
  writeStock,
};
