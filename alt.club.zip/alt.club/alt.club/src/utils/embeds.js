const { EmbedBuilder } = require('discord.js');

function createErrorEmbed(title, description) {
  return new EmbedBuilder()
    .setColor('#FF0000')
    .setTitle(title)
    .setDescription(description);
}

function createSuccessEmbed(title, description) {
  return new EmbedBuilder()
    .setColor('#00FF00')
    .setTitle(title)
    .setDescription(description);
}

function createInfoEmbed(title, description) {
  return new EmbedBuilder()
    .setColor('#0099FF')
    .setTitle(title)
    .setDescription(description);
}

module.exports = {
  createErrorEmbed,
  createSuccessEmbed,
  createInfoEmbed,
};
