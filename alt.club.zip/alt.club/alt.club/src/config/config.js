require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  stockFile: process.env.STOCK_FILE || 'accounts.txt',
  roles: {
    vip: process.env.ROLE_VIP,
    premium: process.env.ROLE_PREMIUM,
    admin: process.env.ROLE_ADMIN,
  },
  cooldowns: {
    default: 3600000,
    vip: 1800000,
    premium: 900000,
    admin: 0,
  },
};
