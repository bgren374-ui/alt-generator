const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { readStock, writeStock } = require('../utils/stock');
const { checkCooldown, setCooldown, getUserCooldown } = require('../utils/cooldown');
const { formatTime } = require('../utils/format');
const { createErrorEmbed, createSuccessEmbed } = require('../utils/embeds');
const { checkRoleAccess } = require('../utils/roleCheck');
const CONFIG = require('../config/config');

function parseAccount(accountLine) {
  const parts = accountLine.split(':');
  if (parts.length < 3) return null;
  
  return {
    username: parts[0],
    password: parts[1],
    cookie: parts.slice(2).join(':'),
  };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gen-prem')
    .setDescription('Generate a premium account (Premium users only)'),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    // Check if user has Premium, VIP, or Admin role
    const hasPremium = CONFIG.roles.premium ? interaction.member.roles.cache.has(CONFIG.roles.premium) : false;
    const hasVip = CONFIG.roles.vip ? interaction.member.roles.cache.has(CONFIG.roles.vip) : false;
    const hasAdmin = CONFIG.roles.admin ? interaction.member.roles.cache.has(CONFIG.roles.admin) : false;
    
    if (!hasPremium && !hasVip && !hasAdmin) {
      const embed = createErrorEmbed(
        '❌ Access Denied', 
        `You need the <@&${CONFIG.roles.premium}>, <@&${CONFIG.roles.vip}>, or <@&${CONFIG.roles.admin}> role to use this command.`
      );
      return interaction.editReply({ embeds: [embed] });
    }

    const { onCooldown, timeLeft } = checkCooldown(interaction.user.id, 'gen-prem');

    if (onCooldown) {
      const embed = createErrorEmbed('⏰ Cooldown Active', `Please wait **${formatTime(timeLeft)}** before generating again.`);
      return interaction.editReply({ embeds: [embed] });
    }

    const stock = await readStock();

    if (!stock.length) {
      const embed = createErrorEmbed('❌ Out of Stock', 'There are no accounts available. Please check back later!');
      return interaction.editReply({ embeds: [embed] });
    }

    const accountLine = stock.shift();
    await writeStock(stock);

    const account = parseAccount(accountLine);
    if (!account) {
      stock.unshift(accountLine);
      await writeStock(stock);
      const embed = createErrorEmbed('❌ Invalid Account', 'The account format is invalid.');
      return interaction.editReply({ embeds: [embed] });
    }

    const cooldownTime = getUserCooldown(interaction.member);
    if (cooldownTime > 0) {
      setCooldown(interaction.user.id, cooldownTime, 'gen-prem');
    }

    try {
      const dmEmbed = new EmbedBuilder()
        .setColor('#f39c12')
        .setTitle('💎 Premium Account Successfully Generated')
        .setDescription('Your premium account credentials are ready to use. Please keep this information safe and secure.')
        .addFields(
          { 
            name: '👤 Username', 
            value: `\`\`\`${account.username}\`\`\``,
            inline: false 
          },
          { 
            name: '🔐 Password', 
            value: `\`\`\`${account.password}\`\`\``,
            inline: false 
          },
          { 
            name: '📋 Login Credentials', 
            value: `\`\`\`${account.username}:${account.password}\`\`\``,
            inline: false 
          },
          { 
            name: '🍪 Cookie Token', 
            value: `\`\`\`${account.cookie}\`\`\``,
            inline: false 
          }
        )
        .setFooter({ text: '⚠️ Never share these credentials with anyone', iconURL: 'https://cdn.discordapp.com/emojis/1024037823395205130.webp' })
        .setTimestamp();

      await interaction.user.send({ embeds: [dmEmbed] });

      const replyEmbed = createSuccessEmbed('✅ Premium Account Generated', 'Check your DMs!')
        .addFields({ name: 'Next Generation', value: cooldownTime > 0 ? formatTime(cooldownTime) : 'No cooldown' });

      await interaction.editReply({ embeds: [replyEmbed] });
    } catch (err) {
      stock.unshift(accountLine);
      await writeStock(stock);

      const embed = createErrorEmbed('❌ DM Failed', 'Unable to send you a DM. Please enable DMs from server members.');
      await interaction.editReply({ embeds: [embed] });
    }
  },
};
