const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { checkRoleAccess } = require('../utils/roleCheck');
const CONFIG = require('../config/config');
const { formatTime } = require('../utils/format');
const { checkCooldown, setCooldown, getUserCooldown } = require('../utils/cooldown');
const { readStock, writeStock } = require('../utils/stock');
const { createErrorEmbed, createSuccessEmbed } = require('../utils/embeds');

function parseAccount(accountLine) {
  const parts = accountLine.split(':');
  if (parts.length < 3) return null;
  
  return {
    username: parts[0],
    password: parts[1],
    cookie: parts.slice(2).join(':'),
  };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gen-panel')
    .setDescription('Display the account generation panel')
    .setDefaultMemberPermissions('0'),

  async execute(interaction) {
    // Only allow users with specific permissions to use this command
    if (!interaction.member.permissions.has('Administrator')) {
      return interaction.reply({
        content: '❌ You do not have permission to use this command.',
        ephemeral: true
      });
    }

    // Create the main embed
    const embed = new EmbedBuilder()
      .setTitle('✨ ALT.CLUB ACCOUNT GENERATOR ✨')
      .setDescription('Select an account type to generate based on your role.')
      .setColor('#FF0000')
      .setThumbnail('https://cdn.discordapp.com/icons/1445180869097689250/059d9ecaf55ff50e593ffa3592ca4143.webp?size=512')
      .addFields(
        { name: '\u200B', value: '**Available Account Types:**' },
        { 
          name: '🔹 Member', 
          value: 'Standard accounts for all members',
          inline: true
        },
        { 
          name: '✨ Premium', 
          value: `Exclusive accounts for <@&${CONFIG.roles.premium}>`,
          inline: true
        },
        { 
          name: '💎 VIP', 
          value: `Elite accounts for <@&${CONFIG.roles.vip}>`,
          inline: true
        }
      )
      .setFooter({ 
        text: 'alt.club • Premium Account Services',
        iconURL: 'https://cdn.discordapp.com/icons/1445180869097689250/059d9ecaf55ff50e593ffa3592ca4143.webp?size=512'
      })
      .setTimestamp();

    // Create buttons for each gen type
    const row1 = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('gen_member')
          .setLabel('Generate Member')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('🔹'),
        new ButtonBuilder()
          .setCustomId('gen_premium')
          .setLabel('Generate Premium')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('✨'),
        new ButtonBuilder()
          .setCustomId('gen_vip')
          .setLabel('Generate VIP')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('💎'),
      );

    // Create a second row for additional buttons
    const row2 = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setURL('https://discord.gg/maAEXdaxgz')
          .setLabel('Join Support Server')
          .setStyle(ButtonStyle.Link)
          .setEmoji('🆘')
      );

    // Send the embed with buttons
    await interaction.reply({
      embeds: [embed],
      components: [row1, row2]
    });
  },

  // Button handler - called when a button is clicked
  async handleButton(interaction) {
    const { customId } = interaction;
    
    // Check which button was clicked
    if (customId.startsWith('gen_')) {
      const genType = customId.split('_')[1]; // 'member', 'premium', or 'vip'
      
      // Check role access using the roleCheck utility
      if (!checkRoleAccess(interaction.member, genType)) {
        let requiredRoles = '';
        
        if (genType === 'vip') {
          requiredRoles = `<@&${CONFIG.roles.vip}> or <@&${CONFIG.roles.admin}>`;
        } else if (genType === 'premium') {
          requiredRoles = `<@&${CONFIG.roles.premium}>, <@&${CONFIG.roles.vip}>, or <@&${CONFIG.roles.admin}>`;
        }
        
        return interaction.reply({
          content: `❌ You don't have the required role to generate ${genType.toUpperCase()} accounts. You need ${requiredRoles}.`,
          ephemeral: true
        });
      }
      
      // Check cooldown
      const commandName = genType === 'member' ? 'gen' : `gen-${genType}`;
      const { onCooldown, timeLeft } = checkCooldown(interaction.user.id, commandName);
      
      if (onCooldown) {
        const embed = createErrorEmbed('⏰ Cooldown Active', `Please wait **${formatTime(timeLeft)}** before generating again.`);
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }
      
      // Defer the reply
      await interaction.deferReply({ ephemeral: true });
      
      // Read stock for the specific type
      const stockFile = genType === 'member' ? 'stock.txt' : `stock-${genType}.txt`;
      const stock = await readStock(stockFile);
      
      if (!stock.length) {
        const embed = createErrorEmbed('❌ Out of Stock', `There are no ${genType.toUpperCase()} accounts available. Please check back later!`);
        return interaction.editReply({ embeds: [embed] });
      }
      
      // Get an account from stock
      const accountLine = stock.shift();
      await writeStock(stock, stockFile);
      
      const account = parseAccount(accountLine);
      if (!account) {
        // Put the account back if parsing failed
        stock.unshift(accountLine);
        await writeStock(stock, stockFile);
        const embed = createErrorEmbed('❌ Invalid Account', 'The account format is invalid.');
        return interaction.editReply({ embeds: [embed] });
      }
      
      // Set cooldown
      const cooldownTime = getUserCooldown(interaction.member, genType);
      if (cooldownTime > 0) {
        setCooldown(interaction.user.id, cooldownTime, commandName);
      }
      
      // Try to send DM
      try {
        const accountTypeEmoji = {
          member: '🔹',
          premium: '✨',
          vip: '💎'
        };
        
        const accountTypeColor = {
          member: '#2ecc71',
          premium: '#9b59b6',
          vip: '#f1c40f'
        };
        
        const dmEmbed = new EmbedBuilder()
          .setColor(accountTypeColor[genType])
          .setTitle(`${accountTypeEmoji[genType]} ${genType.toUpperCase()} Account Generated`)
          .setDescription('Your new account credentials are ready to use. Please keep this information safe and secure.')
          .addFields(
            { 
              name: '👤 Username', 
              value: `\`\`\`${account.username}\`\`\``,
              inline: false 
            },
            { 
              name: '🔐 Password', 
              value: `\`\`\`${account.password}\`\`\``,
              inline: false 
            },
            { 
              name: '📋 Login Credentials', 
              value: `\`\`\`${account.username}:${account.password}\`\`\``,
              inline: false 
            },
            { 
              name: '🍪 Cookie Token', 
              value: `\`\`\`${account.cookie}\`\`\``,
              inline: false 
            }
          )
          .setFooter({ 
            text: '⚠️ Never share these credentials with anyone | alt.club', 
            iconURL: 'https://cdn.discordapp.com/icons/1445180869097689250/059d9ecaf55ff50e593ffa3592ca4143.webp?size=512'
          })
          .setTimestamp();
        
        await interaction.user.send({ embeds: [dmEmbed] });
        
        const replyEmbed = createSuccessEmbed(
          `✅ ${genType.toUpperCase()} Account Generated`, 
          'Check your DMs for your account credentials!'
        ).addFields(
          { name: '📦 Account Type', value: genType.toUpperCase(), inline: true },
          { name: '⏱️ Next Generation', value: cooldownTime > 0 ? formatTime(cooldownTime) : 'No cooldown', inline: true },
          { name: '📊 Remaining Stock', value: `${stock.length} accounts`, inline: true }
        );
        
        await interaction.editReply({ embeds: [replyEmbed] });
        
      } catch (err) {
        // Put the account back if DM failed
        stock.unshift(accountLine);
        await writeStock(stock, stockFile);
        
        const embed = createErrorEmbed('❌ DM Failed', 'Unable to send you a DM. Please enable DMs from server members and try again.');
        await interaction.editReply({ embeds: [embed] });
      }
    }
  }
};