const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show bot commands and information'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#0099FF')
      .setTitle('🤖 Bot Commands')
      .addFields(
        { name: '</gen:0>', value: 'Generate an account (Members)' },
        { name: '</gen-prem:0>', value: 'Generate a premium account (Premium users)' },
        { name: '</gen-vip:0>', value: 'Generate a VIP account (VIP users)' },
        { name: '</stock:0>', value: 'Check current stock count' },
        { name: '</addstock:0>', value: 'Add items to stock (Admin only)' },
        { name: '</help:0>', value: 'Show this help message' },
        { name: '\n**Cooldown System**', value: '• Default: 1 hour\n• VIP: 30 minutes\n• Premium: 15 minutes\n• Admin: No cooldown' }
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
