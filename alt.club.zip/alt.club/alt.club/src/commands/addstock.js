const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { readStock, writeStock } = require('../utils/stock');
const { createErrorEmbed, createSuccessEmbed } = require('../utils/embeds');
const { checkRoleAccess } = require('../utils/roleCheck');
const CONFIG = require('../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addstock')
    .setDescription('Add items to stock (Admin only)')
    .addStringOption(opt =>
      opt.setName('items')
        .setDescription('Items to add (one per line)')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    if (!checkRoleAccess(interaction.member, 'admin')) {
      const embed = createErrorEmbed('❌ Access Denied', `You need the <@&${CONFIG.roles.admin}> role to use this command.`);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const items = interaction.options.getString('items')
      .split('\n')
      .filter(line => line.trim());

    if (!items.length) {
      const embed = createErrorEmbed('❌ Invalid Input', 'Please provide at least one item.');
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const stock = await readStock();
    stock.push(...items);
    await writeStock(stock);

    const embed = createSuccessEmbed('✅ Stock Added', `Added **${items.length}** items.\nTotal: **${stock.length}** items`);
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
