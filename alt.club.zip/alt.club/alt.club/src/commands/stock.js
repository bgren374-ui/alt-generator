const { SlashCommandBuilder } = require('discord.js');
const { readStock } = require('../utils/stock');
const { createInfoEmbed } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stock')
    .setDescription('Check current stock count'),

  async execute(interaction) {
    const stock = await readStock();
    const embed = createInfoEmbed('📦 Stock Status', `**${stock.length}** accounts currently available`);
    await interaction.reply({ embeds: [embed] });
  },
};
