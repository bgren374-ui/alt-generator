const { Client, GatewayIntentBits, REST, Routes, EmbedBuilder } = require('discord.js');
const fs = require('fs').promises;
const path = require('path');
const CONFIG = require('./config/config');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
});

const commands = new Map();

async function loadCommands() {
  try {
    const commandsPath = path.join(__dirname, 'commands');
    const commandFiles = await fs.readdir(commandsPath);
    const jsFiles = commandFiles.filter(file => file.endsWith('.js'));

    console.log(`📝 Loading ${jsFiles.length} command(s)...`);

    for (const file of jsFiles) {
      const filePath = path.join(commandsPath, file);
      const command = require(filePath);
      commands.set(command.data.name, command);
      console.log(`✅ Loaded command: ${command.data.name}`);
    }

    return commands;
  } catch (err) {
    console.error('❌ Error loading commands:', err);
    process.exit(1);
  }
}

async function registerCommands() {
  try {
    console.log('📝 Registering slash commands...');
    const rest = new REST().setToken(CONFIG.token);
    const commandsData = Array.from(commands.values()).map(cmd => cmd.data.toJSON());

    if (CONFIG.guildId) {
      await rest.put(
        Routes.applicationGuildCommands(CONFIG.clientId, CONFIG.guildId),
        { body: commandsData }
      );
      console.log(`✅ Registered ${commandsData.length} command(s) to guild: ${CONFIG.guildId}`);
    } else {
      await rest.put(
        Routes.applicationCommands(CONFIG.clientId),
        { body: commandsData }
      );
      console.log(`✅ Registered ${commandsData.length} command(s) globally`);
    }
  } catch (err) {
    console.error('❌ Error registering commands:', err.message);
  }
}

client.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand()) {
    const command = commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction);
    } catch (err) {
      console.error(`Error in /${interaction.commandName}:`, err);

      const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('❌ Error')
        .setDescription('An error occurred while processing your command.');

      const method = interaction.replied || interaction.deferred ? 'followUp' : 'reply';
      await interaction[method]({ embeds: [embed], ephemeral: true });
    }
  }
  
  else if (interaction.isButton()) {
    if (interaction.customId.startsWith('gen_')) {
      const genPanelCommand = commands.get('gen-panel');
      
      if (genPanelCommand && genPanelCommand.handleButton) {
        try {
          await genPanelCommand.handleButton(interaction);
        } catch (err) {
          console.error('Error handling button:', err);
          
          const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('❌ Error')
            .setDescription('An error occurred while processing your request.');

          const method = interaction.replied || interaction.deferred ? 'followUp' : 'reply';
          await interaction[method]({ embeds: [embed], ephemeral: true });
        }
      } else {
        console.error('gen-panel command or handleButton method not found');
      }
    }
  }
});

client.once('ready', async () => {
  console.log(`✅ Bot logged in as ${client.user.tag}`);
  console.log(`📝 Stock file: ${CONFIG.stockFile}`);
  await registerCommands();
});

async function start() {
  try {
    console.log('🚀 Starting bot...');
    await loadCommands();
    await client.login(CONFIG.token);
  } catch (err) {
    console.error('❌ Failed to start bot:', err);
    process.exit(1);
  }
}

start();